<?php
// c'est ici que sont déposées les images utilisées dans les menus.
?>