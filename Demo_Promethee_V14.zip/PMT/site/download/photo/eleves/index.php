<?php
// c'est ici que sont déposées les photos des élèves.
?>