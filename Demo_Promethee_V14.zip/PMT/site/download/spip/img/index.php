<?php
// c'est ici que sont déposées les images illustrants les articles.
?>