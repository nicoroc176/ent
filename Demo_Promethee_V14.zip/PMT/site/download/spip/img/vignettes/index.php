<?php
// c'est ici que sont déposées les vignettes des images illustrants les articles.
?>