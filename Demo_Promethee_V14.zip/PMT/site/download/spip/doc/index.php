<?php
// c'est ici que sont déposés les documents joints aux articles.
?>