<?php
// c'est ici que sont déposées les images pour être importées dans une galerie.
?>