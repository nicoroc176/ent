<?php
// c'est ici que sont déposées les images de chaque galerie.
?>