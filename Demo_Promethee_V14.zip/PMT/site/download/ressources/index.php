<?php
// c'est la zone d'upload pour les resources pédagos et administratives.
?>