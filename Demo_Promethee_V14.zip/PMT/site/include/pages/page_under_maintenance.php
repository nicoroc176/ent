<?php
  // Page de maintenance
  $alert->info('Maintenance', 'Cette page est en cours de maintenance, merci de revenir après la mise à jours');
?>

<a href="index.php" class="btn btn-secondary"><i class="fas fa-chevron-left"></i>&nbsp;Revenir à l'accueil</a>
