<?php

// Classe relative au centre actuel
class Center {
  /**
   * ID du centre actuel
   *
   * @var string
   */
  public $idcentre;


  function getCenterID() {

  }


}


?>
